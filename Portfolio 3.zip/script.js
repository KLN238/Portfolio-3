document.addEventListener("DOMContentLoaded", function () {
    const links = document.querySelectorAll(".nav-link");
    const content = document.querySelector(".content");

    // Fonction pour charger le contenu de la page sans rechargement
    function loadPage(page) {
        fetch(page) // Charge le fichier HTML demandé
            .then(response => {
                if (!response.ok) {
                    throw new Error("Page introuvable");
                }
                return response.text();
            })
            .then(data => {
                const tempDiv = document.createElement("div");
                tempDiv.innerHTML = data;

                const newContent = tempDiv.querySelector(".content");
                if (newContent) {
                    content.innerHTML = newContent.innerHTML; // Remplace uniquement le contenu principal
                    history.pushState({ page }, "", page); // Met à jour l'URL sans recharger
                }
            })
            .catch(error => console.error("Erreur de chargement :", error));
    }

    // Événement sur chaque lien de la barre latérale
    links.forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault(); // Empêche le rechargement de la page
            const page = this.getAttribute("href");

            // Met à jour la classe active des liens
            links.forEach(l => l.classList.remove("active"));
            this.classList.add("active");

            loadPage(page);
        });
    });

    // Gérer l'historique du navigateur (bouton retour)
    window.addEventListener("popstate", function (event) {
        if (event.state && event.state.page) {
            loadPage(event.state.page);
        }
    });

    // Charger "accueil.html" au démarrage par défaut
    const currentPage = location.pathname.split("/").pop() || "accueil.html";
    loadPage(currentPage);

    // Configuration EmailJS
    emailjs.init("1tkgaPdIZxjW5F8dz");

    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const message = document.getElementById("message").value.trim();
            const statusMessage = document.getElementById("status-message");

            if (name === "" || email === "" || message === "") {
                statusMessage.textContent = "Veuillez remplir tous les champs.";
                statusMessage.style.color = "red";
                return;
            }

            const templateParams = {
                user_name: name,
                user_email: email,
                user_message: message,
            };

            emailjs.send("service_Portfolio", "template_portfolio", templateParams)
                .then(() => {
                    statusMessage.textContent = "Message envoyé avec succès ! ✅";
                    statusMessage.style.color = "green";
                    contactForm.reset();
                })
                .catch(() => {
                    statusMessage.textContent = "Erreur lors de l'envoi ❌";
                    statusMessage.style.color = "red";
                });
        });
    }
});
